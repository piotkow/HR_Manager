using BenchmarkDotNet.Attributes;
using HRManager.Benchmarks.Config;
using Microsoft.EntityFrameworkCore;

namespace HRManager.Benchmarks.Benchmarks;

/// <summary>
/// Scenariusz 1: �ledzenie zmian (Tracking vs. NoTracking)
/// 
/// Badanie narzutu wydajno�ciowego ChangeTrackera przy operacjach tylko do odczytu (read-only)
/// dla ma�ych (100) i du�ych (10 000+) zbior�w danych.
/// 
/// Metryki: Czas wykonania, Alokacja pami�ci
/// </summary>
[Config(typeof(BenchmarkConfig))]
[MemoryDiagnoser]
public class TrackingVsNoTrackingBenchmarks : BenchmarkBase
{
    [Params(10, 100, 1000)]
    public int RecordCount { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        // Upewnij si�, �e baza danych istnieje i ma dane testowe
        using var context = CreateContext();
        context.Database.EnsureCreated();
        
        // Sprawd� liczb� rekord�w
        var count = context.Employees.Count();
        Console.WriteLine($"Liczba pracownik�w w bazie: {count}");
        
        // Je�li potrzebujesz wi�cej danych testowych, mo�esz je tutaj doda�
        // EnsureTestData(context, RecordCount);
    }

    /// <summary>
    /// Pobieranie z domy�lnym �ledzeniem zmian (Tracking)
    /// ChangeTracker �ledzi wszystkie pobrane encje
    /// </summary>
    [Benchmark(Baseline = true)]
    public async Task<List<HRManager.Models.Entities.Employee>> WithTracking()
    {
        using var context = CreateContext();
        return await context.Employees
            .Take(RecordCount)
            .ToListAsync();
    }

    /// <summary>
    /// Pobieranie bez �ledzenia zmian (NoTracking)
    /// Brak narzutu ChangeTrackera - szybsze dla operacji read-only
    /// </summary>
    [Benchmark]
    public async Task<List<HRManager.Models.Entities.Employee>> WithNoTracking()
    {
        using var context = CreateContext();
        return await context.Employees
            .AsNoTracking()
            .Take(RecordCount)
            .ToListAsync();
    }

    /// <summary>
    /// Pobieranie z NoTracking na poziomie DbContext
    /// </summary>
    [Benchmark]
    public async Task<List<HRManager.Models.Entities.Employee>> WithNoTrackingContext()
    {
        using var context = CreateNoTrackingContext();
        return await context.Employees
            .Take(RecordCount)
            .ToListAsync();
    }

    /// <summary>
    /// NoTracking z Include (eager loading bez �ledzenia)
    /// </summary>
    [Benchmark]
    public async Task<List<HRManager.Models.Entities.Employee>> WithNoTracking_WithInclude()
    {
        using var context = CreateContext();
        return await context.Employees
            .AsNoTracking()
            .Include(e => e.Position)
            .Include(e => e.Team)
            .Take(RecordCount)
            .ToListAsync();
    }

    /// <summary>
    /// Tracking z Include (eager loading ze �ledzeniem)
    /// </summary>
    [Benchmark]
    public async Task<List<HRManager.Models.Entities.Employee>> WithTracking_WithInclude()
    {
        using var context = CreateContext();
        return await context.Employees
            .Include(e => e.Position)
            .Include(e => e.Team)
            .Take(RecordCount)
            .ToListAsync();
    }
}
