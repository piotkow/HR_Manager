using HRManager.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace HRManager.Benchmarks.Benchmarks;

/// <summary>
/// Klasa bazowa dla wszystkich benchmark�w
/// Zawiera konfiguracj� po��czenia z baz� danych
/// </summary>
public abstract class BenchmarkBase
{
    protected const string ConnectionString = 
        @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=HRManager;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

    /// <summary>
    /// Tworzy nowy DbContext z domy�lnymi ustawieniami
    /// </summary>
    protected HRManagerDbContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<HRManagerDbContext>()
            .UseSqlServer(ConnectionString)
            .Options;
        return new HRManagerDbContext(options);
    }

    /// <summary>
    /// Tworzy nowy DbContext bez �ledzenia zmian (NoTracking)
    /// </summary>
    protected HRManagerDbContext CreateNoTrackingContext()
    {
        var options = new DbContextOptionsBuilder<HRManagerDbContext>()
            .UseSqlServer(ConnectionString)
            .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
            .Options;
        return new HRManagerDbContext(options);
    }

    /// <summary>
    /// Tworzy nowy DbContext z Split Query jako domy�lnym
    /// </summary>
    protected HRManagerDbContext CreateSplitQueryContext()
    {
        var options = new DbContextOptionsBuilder<HRManagerDbContext>()
            .UseSqlServer(ConnectionString, o => o.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery))
            .Options;
        return new HRManagerDbContext(options);
    }

    /// <summary>
    /// Tworzy po��czenie SQL dla Dapper i ADO.NET
    /// </summary>
    protected SqlConnection CreateSqlConnection()
    {
        return new SqlConnection(ConnectionString);
    }
}
